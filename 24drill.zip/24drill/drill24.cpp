//elozo ora: functorok
//mai ora: numerikusok:matrixok

//24.drill

#include <string>
#include <iostream>
#include <iomanip>
#include <complex>
#include <cmath>
#include <cerrno>
#include "Matrix.h"
#include "MatrixIO.h"

using namespace std;
using namespace Numeric_lib;

int main(){
	try{

	cout << "sizeof: \n";
	cout << "char\t" << sizeof(char) << "\n";
	cout << "short\t" << sizeof(short) << "\n";
	cout << "int\t" << sizeof(int) << "\n";
	cout << "long\t" << sizeof(long) << "\n";
	cout << "float\t" << sizeof(float) << "\n";
	cout << "double\t" << sizeof(double) << "\n";
	cout << "int*\t" << sizeof(int*) << "\n";
	cout << "double*\t" << sizeof(double*) << "\n";
	cout << "float*\t" << sizeof(float*) << "\n";
	cout << "long*\t" << sizeof(long*) << "\n";
	//pointerek maximalis memoriateruletet hasznalnak (8 bájtosak :D), memoria tervezes szempontjabol hatranyos
	
	//int matrixok:
	Matrix<int> a(10);//1d eseteben nem kell megadni a d szamat
	Matrix<int> b(100);
	Matrix<double> c (10);
	Matrix<int, 2> d(10, 10);
	Matrix<int, 3> e(10,10,10);
	//kiir
	cout << "1D int, 10 elements \t\t" << sizeof(a) << "\n";
	cout << "1D int, 100 elements \t\t" << sizeof(b) << "\n";
	cout << "1D double, 10 elements \t\t" << sizeof(c) << "\n";
	cout << "2D int, 10x10 elements \t\t" << sizeof(d) << "\n";
	cout << "3D int, 10x10x10 elements \t\t" << sizeof(e) << "\n";
	//memoria foglalas szempontjabol: b 32 meretu hiaba 100 elem, dinamikus memoria kezeles van, alapbol nem hasznalja ki maximalisan a meoriat a deklaralas
	//ezek kezdeti ertekek
	
	//elemek szama kiir
		//size() indexet ad majd vissza
	cout << "\nNumber of elements: ";
	cout << "a:\t"<< a.size() << '\n';
	cout << "b:\t"<< b.size() << '\n';
	cout << "c:\t"<< c.size() << '\n';
	cout << "d:\t"<< d.size() << '\n';
	cout << "e:\t"<< e.size() << '\n';
	//memoria foglalastol fuggetlenul megvannak az elemek szama minden esetben
	
	//cin bekeres, gyökvonás
	int jaj;
	cout << "enter a number: ";
	while(cin >> jaj){
		errno = 0;
		double ajaj = sqrt(jaj);
		if(errno == EDOM)
			cout << "no square root\n";
		else
			cout << "sqrt of " << jaj << ": " << sqrt(jaj) << '\n';
		}
	
	
	cin.clear(); //urites
	cin.ignore(); // legutolso karaktert figyelmen kivul hagyja
	cout << "Enter 10 floating point values:";
	Matrix<double>m2(10);
	double szam;
	for(int i=0; i<m2.size(); ++i){
		cin >> szam;
		if(!cin) throw runtime_error("Problem reading from cin.");
		m2[i] = szam;
		}
	cout << "Matrix:\n" << m2 << '\n';
	
	//szorzotabla
	cout << "Multiplication table\nEnter n: ";
	int n;
	cin >> n;
	cout << "Enter m: ";
	int m3;
	cin >> m3;
	Matrix<int, 2> szT(n, m3);
	//vedes: index: matrix sajat long tipusna 
	for(Index i=0; i<szT.dim1(); ++i){
		for(Index j=0; j<szT.dim2(); ++j){
			szT(i, j) = (i+1)*(j+1);
			cout << setw(5) <<szT(i, j);
		}
		cout << '\n';
	}
	//10 komplex szam beolvasasa:
	Matrix<complex<double>> m4(10);
	cout << "\nEnter 10 complex numbers(Re, Im): ";
	complex<double> comp;
	for(int i=0; i<10;++i){
		cin >> comp;
		if(!cin) throw runtime_error("Problem reading complex number!");
		m4[i] = comp;
		}
	cout << "Complex matrix: " << m4 << '\n';
	complex<double> sum;
	for(Index i=0; i<m4.size(); ++i){
		sum+= m4[i];
	}
	cout << "Sum: " << sum << '\n'; //komplex szamnal nem kell 1erteket adni, 0val kezdodik
	
	//utolso feladat: hazi
	cout << "Enter 6 numbers: " << '\n';
	Matrix<int,2> m8(2,3);
	int szam2;
	for(Index i=0; i<m8.size(); ++i){
		cin >> szam2;
		if(!cin) throw runtime_error("Problem reading from cin.");
		m8[i] = szam2;
		}
	cout << "Matrix:\n" << m8 << '\n';
	



	}catch(exception& e){
		cerr << "exception: " << e.what() << endl;
		return 1;
	}catch(...){
		cerr << "exception: " << '\n';
		return 2;
	}
}
